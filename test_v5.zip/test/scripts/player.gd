extends CharacterBody2D

signal xp_changed

@export_enum("a1", "a2", "b1", "b2", "c1")
var nivel: String = "a1"

@export var xp: int = 0

var vel := 400.0

const NIVELES := {
	"a1": 0,
	"a2": 10,
	"b1": 25,
	"b2": 50,
	"c1": 100
}

const ORDEN_NIVELES := [
	"a1",
	"a2",
	"b1",
	"b2",
	"c1"
]


func _ready():
	xp = max(0, xp)
	_actualizar_nivel()


func _physics_process(_delta):
	var input_direction := Input.get_vector(
		"ui_left",
		"ui_right",
		"ui_up",
		"ui_down"
	)

	velocity = input_direction * vel
	move_and_slide()


func add_xp(amount: int) -> void:
	var nueva_xp: int = max(0, xp + amount)

	if nueva_xp == xp:
		return

	xp = nueva_xp
	_actualizar_nivel()

	xp_changed.emit()


func _actualizar_nivel() -> void:
	var nuevo_nivel := "a1"

	for nivel_nombre in ORDEN_NIVELES:
		if xp >= NIVELES[nivel_nombre]:
			nuevo_nivel = nivel_nombre
		else:
			break

	if nuevo_nivel != nivel:
		print("Nivel cambiado: %s → %s" % [nivel, nuevo_nivel])
		nivel = nuevo_nivel
