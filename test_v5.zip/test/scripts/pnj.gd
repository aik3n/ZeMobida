extends CharacterBody2D

@export var nombre: String = "PNJ"
@export var sprite: Texture2D

var player_nearby := false

@onready var sprite_2d: Sprite2D = $Sprite2D


func _ready():
	sprite_2d.texture = sprite


func get_map_name() -> String:
	var scene_path := get_tree().current_scene.scene_file_path
	return scene_path.get_file().get_basename()


func get_dialogue_file() -> String:
	var map_name := get_map_name()
	var player = get_tree().current_scene.get_node_or_null("player")

	if player == null:
		push_error("No se encontró el Player en la escena actual.")
		return ""

	var base_name := "%s_%s" % [map_name, nombre]

	# 1. Diálogo específico para el nivel.
	var level_file := "%s_%s.txt" % [base_name, player.nivel]
	var level_path := "res://dialogues/" + level_file

	if FileAccess.file_exists(level_path):
		return level_file

	# 2. Diálogo independiente del nivel.
	var generic_character_file := "%s.txt" % base_name
	var generic_character_path := "res://dialogues/" + generic_character_file

	if FileAccess.file_exists(generic_character_path):
		return generic_character_file

	# 3. Diálogo genérico global.
	var generic_file := "generico.txt"
	var generic_path := "res://dialogues/" + generic_file

	if FileAccess.file_exists(generic_path):
		return generic_file

	push_error(
		"No existe diálogo para '%s' ni diálogo genérico." % base_name
	)

	return ""


func _on_interaction_area_body_entered(body):
	if body.name != "player":
		return

	player_nearby = true

	if not DialogueManager.dialogue_active:
		var dialogue_file := get_dialogue_file()

		if dialogue_file.is_empty():
			return

		DialogueManager.start_dialogue(
			"res://dialogues/" + dialogue_file
		)


func _on_interaction_area_body_exited(body):
	if body.name != "player":
		return

	player_nearby = false

	if DialogueManager.dialogue_active:
		DialogueManager.end_dialogue()


func _on_interaction_area_area_exited(area):
	pass
