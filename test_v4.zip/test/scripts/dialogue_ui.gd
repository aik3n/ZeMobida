extends CanvasLayer

@onready var name_label: Label = $Panel/NameLabel
@onready var dialogue_text: Label = $Panel/DialogueText
@onready var options_container: VBoxContainer = $Panel/OptionsContainer

@onready var level_label: Label = $Panel2/lbl_nivel
@onready var xp_bar: ProgressBar = $Panel2/bar_progreso


const NIVELES := {
	"a1": 0,
	"a2": 10,
	"b1": 25,
	"b2": 50,
	"c1": 100
}

const ORDEN_NIVELES := [
	"a1",
	"a2",
	"b1",
	"b2",
	"c1"
]


func _ready():
	DialogueManager.register_ui(self)
	_actualizar_xp()


func _process(_delta):
	_actualizar_xp()


func show_dialogue():
	$Panel.visible = true


func hide_dialogue():
	$Panel.visible = false


func show_text(speaker_name: String, text: String):
	name_label.text = speaker_name
	dialogue_text.text = text


func show_options(options: Array):
	for child in options_container.get_children():
		child.queue_free()

	for option in options:
		var button := Button.new()

		# El número es solo una ayuda para el guionista/parser.
		# No se muestra al jugador.
		button.text = option["text"]
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		options_container.add_child(button)

		button.pressed.connect(
			_on_option_pressed.bind(option)
		)


func _on_option_pressed(option: Dictionary):
	DialogueManager.select_option(option)


func _actualizar_xp():
	var player = get_tree().current_scene.get_node_or_null("player")

	if player == null:
		return

	var nivel: String = player.nivel.to_lower()
	var xp: int = player.xp

	level_label.text = nivel.to_upper()

	var nivel_actual_xp: int = NIVELES[nivel]

	# C1 es el nivel máximo.
	if nivel == "c1":
		xp_bar.min_value = 0
		xp_bar.max_value = 1
		xp_bar.value = 1
		xp_bar.tooltip_text = "%d XP" % xp
		return

	var indice := ORDEN_NIVELES.find(nivel)

	if indice == -1 or indice + 1 >= ORDEN_NIVELES.size():
		return

	var siguiente_nivel: String = ORDEN_NIVELES[indice + 1]
	var siguiente_nivel_xp: int = NIVELES[siguiente_nivel]

	var xp_en_nivel := xp - nivel_actual_xp
	var xp_necesaria := siguiente_nivel_xp - nivel_actual_xp

	xp_bar.min_value = 0
	xp_bar.max_value = xp_necesaria
	xp_bar.value = clamp(xp_en_nivel, 0, xp_necesaria)

	xp_bar.tooltip_text = "%d / %d XP" % [
		xp_en_nivel,
		xp_necesaria
	]
