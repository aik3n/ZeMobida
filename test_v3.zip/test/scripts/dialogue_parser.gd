class_name DialogueParser
extends RefCounted

const IDENTIFIER_PATTERN := r"^[A-Za-z0-9_]+$"

var errors: Array[String] = []


func parse(text: String) -> Dictionary:
	errors.clear()

	var dialogue_data: Dictionary = {}
	var current_node_name := ""
	var current_node: Dictionary = {}
	var line_number := 0

	for raw_line in text.split("\n"):
		line_number += 1

		# -- inicia comentario hasta el final de la línea.
		var line := _remove_comment(raw_line).strip_edges().replace("\t", " ")
		if line.is_empty():
			continue

		# # NODO
		if line.begins_with("#"):
			if not current_node_name.is_empty():
				_store_node(dialogue_data, current_node_name, current_node)

			var node_name := line.substr(1).strip_edges()

			if not _is_valid_identifier(node_name):
				_error(line_number, "Identificador de nodo inválido: '%s'." % node_name)
				current_node_name = ""
				current_node = {}
				continue

			if dialogue_data.has(node_name):
				_error(line_number, "Nodo duplicado: '%s'." % node_name)

			current_node_name = node_name
			current_node = {
				"text": "",
				"conditions": [],
				"options": []
			}
			continue

		if current_node_name.is_empty():
			_error(line_number, "Contenido fuera de un nodo.")
			continue

		var arrow_count := _count_occurrences(line, "->")
		if arrow_count > 1:
			_error(line_number, "Una línea solo puede contener un '->'.")
			continue

		# ?objeto ?objeto -> NODO
		if line.begins_with("?"):
			_parse_condition(line, current_node, line_number)
			continue

		# Una línea que empieza por número es una opción del jugador.
		if _starts_with_number(line):
			_parse_option(line, current_node, line_number)
			continue

		# Si usa sintaxis reservada pero no es válida, es un error.
		if "->" in line or line.begins_with("["):
			_error(line_number, "Sintaxis inválida.")
			continue

		# Texto normal.
		if not current_node["text"].is_empty():
			current_node["text"] += "\n"
		current_node["text"] += line

	if not current_node_name.is_empty():
		_store_node(dialogue_data, current_node_name, current_node)

	_validate_destinations(dialogue_data)

	return dialogue_data


func get_errors() -> Array[String]:
	return errors.duplicate()


func _parse_condition(line: String, node: Dictionary, line_number: int) -> void:
	var parts := line.split("->", false, 1)
	if parts.size() != 2:
		_error(line_number, "Condición sin destino.")
		return

	var condition_part := parts[0].strip_edges()
	var destination := parts[1].strip_edges()

	if not _is_valid_identifier(destination):
		_error(line_number, "Destino inválido: '%s'." % destination)
		return

	var items: Array[String] = []
	for token in condition_part.split(" ", false):
		token = token.strip_edges()
		if token.is_empty():
			continue

		if not token.begins_with("?"):
			_error(line_number, "Condición inválida: '%s'." % token)
			return

		var item := token.substr(1).to_lower()
		if not _is_valid_identifier(item):
			_error(line_number, "Identificador de objeto inválido: '%s'." % item)
			return

		items.append(item)

	if items.is_empty():
		_error(line_number, "La condición no contiene objetos.")
		return

	node["conditions"].append({
		"items": items,
		"next": destination
	})


func _parse_option(line: String, node: Dictionary, line_number: int) -> void:
	var parts := line.split("->", false, 1)
	if parts.size() != 2:
		_error(line_number, "Opción sin destino.")
		return

	var left := parts[0].strip_edges()
	var right := parts[1].strip_edges()

	var number_end := 0
	while number_end < left.length() and left[number_end] >= "0" and left[number_end] <= "9":
		number_end += 1

	if number_end == 0:
		_error(line_number, "Opción inválida.")
		return

	var number_text := left.substr(0, number_end)
	var option_text := left.substr(number_end).strip_edges()

	if option_text.is_empty():
		_error(line_number, "Opción sin texto.")
		return

	var destination := right
	var effects: Array = []

	var open_bracket := right.find("[")
	if open_bracket != -1:
		if not right.ends_with("]"):
			_error(line_number, "Los efectos deben terminar con ']'.")
			return

		destination = right.substr(0, open_bracket).strip_edges()
		var effects_text := right.substr(
			open_bracket + 1,
			right.length() - open_bracket - 2
		)
		effects = _parse_effects(effects_text, line_number)

	if not _is_valid_identifier(destination):
		_error(line_number, "Destino inválido: '%s'." % destination)
		return

	node["options"].append({
		"number": int(number_text),
		"text": option_text,
		"next": destination,
		"effects": effects
	})


func _parse_effects(text: String, line_number: int) -> Array:
	var effects: Array = []

	if text.strip_edges().is_empty():
		return effects

	for raw_effect in text.split(","):
		var effect := raw_effect.strip_edges()

		if effect.is_empty():
			_error(line_number, "Efecto vacío.")
			continue

		# +objeto / -objeto
		if effect.begins_with("+") or effect.begins_with("-"):
			var operation := effect.substr(0, 1)
			var item := effect.substr(1).to_lower()

			if not _is_valid_identifier(item):
				_error(line_number, "Objeto inválido en efecto: '%s'." % effect)
				continue

			effects.append({
				"type": "add_item" if operation == "+" else "remove_item",
				"item": item
			})
			continue

		# xp+N / xp-N
		if effect.begins_with("xp+") or effect.begins_with("xp-"):
			var operation := effect.substr(2, 1)
			var amount_text := effect.substr(3)

			if not amount_text.is_valid_int():
				_error(line_number, "Cantidad de XP inválida: '%s'." % effect)
				continue

			var amount := int(amount_text)
			if amount < 0:
				_error(line_number, "Cantidad de XP inválida: '%s'." % effect)
				continue

			effects.append({
				"type": "xp",
				"value": amount if operation == "+" else -amount
			})
			continue

		_error(line_number, "Efecto desconocido: '%s'." % effect)

	return effects


func _store_node(dialogue_data: Dictionary, node_name: String, node: Dictionary) -> void:
	if not dialogue_data.has(node_name):
		dialogue_data[node_name] = node


func _validate_destinations(dialogue_data: Dictionary) -> void:
	for node_name in dialogue_data:
		var node: Dictionary = dialogue_data[node_name]

		for condition in node["conditions"]:
			if not dialogue_data.has(condition["next"]):
				_error(
					0,
					"El nodo '%s' referencia un destino inexistente: '%s'."
					% [node_name, condition["next"]]
				)

		for option in node["options"]:
			if not dialogue_data.has(option["next"]):
				_error(
					0,
					"El nodo '%s' referencia un destino inexistente: '%s'."
					% [node_name, option["next"]]
				)


func _remove_comment(line: String) -> String:
	var comment_start := line.find("--")
	if comment_start == -1:
		return line
	return line.substr(0, comment_start)


func _is_valid_identifier(value: String) -> bool:
	if value.is_empty():
		return false

	var regex := RegEx.new()
	regex.compile(IDENTIFIER_PATTERN)
	return regex.search(value) != null


func _starts_with_number(line: String) -> bool:
	return not line.is_empty() and line[0] >= "0" and line[0] <= "9"


func _count_occurrences(text: String, needle: String) -> int:
	var count := 0
	var from := 0

	while true:
		var index := text.find(needle, from)
		if index == -1:
			break

		count += 1
		from = index + needle.length()

	return count


func _error(line_number: int, message: String) -> void:
	if line_number > 0:
		errors.append("Línea %d: %s" % [line_number, message])
	else:
		errors.append(message)
