extends CharacterBody2D

@export var nombre: String = "PNJ"
@export var sprite: Texture2D

var player_nearby := false

@onready var sprite_2d: Sprite2D = $Sprite2D


func _ready():
	sprite_2d.texture = sprite


func get_map_name() -> String:
	var scene_path := get_tree().current_scene.scene_file_path
	return scene_path.get_file().get_basename()


func get_dialogue_file() -> String:
	var map_name := get_map_name()
	var player = get_tree().current_scene.get_node_or_null("player")

	if player == null:
		push_error("No se encontró el Player en la escena actual.")
		return ""

	var specific_file := "%s_%s_%s.txt" % [map_name, nombre, player.nivel]
	var specific_path := "res://dialogues/" + specific_file

	if FileAccess.file_exists(specific_path):
		return specific_file

	var generic_path := "res://dialogues/generico.txt"

	if FileAccess.file_exists(generic_path):
		return "generico.txt"

	push_error(
		"No existe el diálogo específico ni el diálogo genérico para: "
		+ specific_file
	)

	return ""


func _on_interaction_area_body_entered(body):
	if body.name != "player":
		return

	player_nearby = true

	if not DialogueManager.dialogue_active:
		var dialogue_file := get_dialogue_file()

		if dialogue_file.is_empty():
			return

		DialogueManager.start_dialogue(
			"res://dialogues/" + dialogue_file
		)


func _on_interaction_area_body_exited(body):
	if body.name != "player":
		return

	player_nearby = false

	if DialogueManager.dialogue_active:
		DialogueManager.end_dialogue()


func _on_interaction_area_area_exited(area):
	pass
