class_name DialogueParser
extends RefCounted


func parse(text: String) -> Dictionary:
	var dialogue_data: Dictionary = {}

	var current_node := ""
	var current_text := ""
	var current_options: Array = []

	var lines := text.split("\n")

	for raw_line in lines:
		var line := raw_line.strip_edges()

		# Ignorar líneas vacías
		if line.is_empty():
			continue

		# Detectar una etiqueta:
		# [START]
		# [LLAVE]
		# [END]
		if line.begins_with("[") and line.ends_with("]"):
			# Guardar el nodo anterior antes de comenzar uno nuevo
			if not current_node.is_empty():
				dialogue_data[current_node] = {
					"text": current_text.strip_edges(),
					"options": current_options
				}

			current_node = line.substr(1, line.length() - 2).strip_edges()
			current_text = ""
			current_options = []

			continue

		# Detectar una opción:
		# Texto de opción -> destino
		if "->" in line:
			var parts := line.split("->", false, 1)

			if parts.size() == 2:
				var option_text := parts[0].strip_edges()
				var destination := parts[1].strip_edges()

				current_options.append({
					"text": option_text,
					"next": destination
				})

				continue

		# Si no es etiqueta ni opción, es texto
		if not current_text.is_empty():
			current_text += "\n"

		current_text += line

	# Guardar el último nodo
	if not current_node.is_empty():
		dialogue_data[current_node] = {
			"text": current_text.strip_edges(),
			"options": current_options
		}

	return dialogue_data
