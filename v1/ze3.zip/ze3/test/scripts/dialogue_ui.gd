extends CanvasLayer

@onready var name_label = $Panel/NameLabel
@onready var dialogue_text = $Panel/DialogueText
@onready var options_container = $Panel/OptionsContainer


func _ready():
	DialogueManager.register_ui(self)


func show_dialogue():
	$Panel.visible = true


func hide_dialogue():
	$Panel.visible = false


func show_text(speaker_name: String, text: String):
	name_label.text = speaker_name
	dialogue_text.text = text


func show_options(options: Array[String]):
	for child in options_container.get_children():
		child.queue_free()

	for option_text in options:
		var button := Button.new()

		button.text = option_text
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL

		options_container.add_child(button)

		button.pressed.connect(
			_on_option_pressed.bind(option_text)
		)


func _on_option_pressed(option_text: String):
	DialogueManager.select_option(option_text)
