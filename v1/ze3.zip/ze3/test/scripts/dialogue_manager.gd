extends Node

var current_node := ""
var dialogue_active := false
var dialogue_ui = null
var current_dialogue_file := ""


func register_ui(ui):
	dialogue_ui = ui


func start_dialogue(file_path: String):
	if dialogue_active:
		return

	dialogue_active = true
	current_dialogue_file = file_path

	load_dialogue(file_path)


func load_dialogue(file_path: String):
	var file = FileAccess.open(file_path, FileAccess.READ)

	if file == null:
		push_error("No se pudo abrir el diálogo: " + file_path)
		end_dialogue()
		return

	var text = file.get_as_text()

	print(text)


func end_dialogue():
	if not dialogue_active:
		return

	dialogue_active = false
	current_node = ""
	current_dialogue_file = ""

	if dialogue_ui != null:
		dialogue_ui.hide_dialogue()
