extends CharacterBody2D
#@onready var sprite_2d: Sprite2D = $Sprite2D


var vel = 400.0

func _physics_process(delta):
	var input_direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	velocity = input_direction * vel
	move_and_slide()
	#print(input_direction)
	
	
