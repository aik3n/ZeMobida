extends CharacterBody2D

var player_nearby := false

func _on_interaction_area_body_entered(body):
	if body.name == "Player":
		player_nearby = true

		if not DialogueManager.dialogue_active:
			DialogueManager.start_dialogue(
				"res://dialogues/pueblo_anciano_a1.txt"
			)

func _on_interaction_area_body_exited(body):
	if body.name == "Player":
		player_nearby = false

		DialogueManager.end_dialogue()
		
