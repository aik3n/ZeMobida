extends Node

var current_node := ""
var dialogue_active := false
var dialogue_ui = null
var current_dialogue_file := ""

var dialogue_data: Dictionary = {}
var inventory: Array[String] = []
var xp := 0

var _parser := DialogueParser.new()


func register_ui(ui):
	dialogue_ui = ui


func start_dialogue(file_path: String):
	if dialogue_active:
		return

	dialogue_active = true
	current_dialogue_file = file_path
	load_dialogue(file_path)


func load_dialogue(file_path: String):
	var file = FileAccess.open(file_path, FileAccess.READ)
	if file == null:
		push_error("No se pudo abrir el diálogo: " + file_path)
		end_dialogue()
		return

	var text := file.get_as_text()
	dialogue_data = _parser.parse(text)

	var errors := _parser.get_errors()
	if not errors.is_empty():
		for error in errors:
			push_error("Error de diálogo (%s): %s" % [file_path, error])
		end_dialogue()
		return

	if dialogue_data.is_empty():
		push_error("El diálogo está vacío: " + file_path)
		end_dialogue()
		return

	# El primer nodo del archivo es el nodo inicial.
	show_node(dialogue_data.keys()[0])


func show_node(node_name: String):
	if not dialogue_data.has(node_name):
		push_error("Nodo inexistente: " + node_name)
		end_dialogue()
		return

	current_node = node_name
	var node: Dictionary = dialogue_data[node_name]

	# Las condiciones se evalúan de arriba abajo.
	for condition in node["conditions"]:
		if _has_all_items(condition["items"]):
			show_node(condition["next"])
			return

	if dialogue_ui != null:
		dialogue_ui.show_dialogue()
		dialogue_ui.show_text("", node["text"])
		dialogue_ui.show_options(node["options"])


func select_option(option: Dictionary):
	if not dialogue_active:
		return

	if not dialogue_data.has(current_node):
		return

	var node: Dictionary = dialogue_data[current_node]

	# La opción recibida por la UI debe existir en el nodo actual.
	for candidate in node["options"]:
		if candidate == option:
			_apply_effects(candidate["effects"])
			show_node(candidate["next"])
			return


func _apply_effects(effects: Array):
	for effect in effects:
		match effect["type"]:
			"add_item":
				add_item(effect["item"])

			"remove_item":
				remove_item(effect["item"])

			"xp":
				xp += int(effect["value"])


func _has_all_items(items: Array) -> bool:
	for item in items:
		if not inventory.has(item):
			return false
	return true


func has_item(item: String) -> bool:
	return inventory.has(item.to_lower())


func add_item(item: String) -> void:
	item = item.to_lower()
	if not inventory.has(item):
		inventory.append(item)


func remove_item(item: String) -> void:
	inventory.erase(item.to_lower())


func end_dialogue():
	if not dialogue_active:
		return

	dialogue_active = false
	current_node = ""
	current_dialogue_file = ""
	dialogue_data.clear()

	if dialogue_ui != null:
		dialogue_ui.hide_dialogue()
