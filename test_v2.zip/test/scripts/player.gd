extends CharacterBody2D

@export_enum("a1", "a2", "b1", "b2", "c1")
var nivel: String = "a1"

var vel = 400.0

func _physics_process(delta):
	var input_direction = Input.get_vector(
		"ui_left",
		"ui_right",
		"ui_up",
		"ui_down"
	)

	velocity = input_direction * vel
	move_and_slide()
