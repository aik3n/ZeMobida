extends Node


const BIENVENIDA_SCENE := "res://escenas/bienvenida.tscn"
const ALDEA_SCENE := "res://escenas/aldea.tscn"

@onready var scene_container: Node = $SceneContainer


func _ready() -> void:
	cargar_escena(BIENVENIDA_SCENE)


func cargar_escena(scene_path: String) -> void:

	for child in scene_container.get_children():
		child.queue_free()

	var scene: PackedScene = load(scene_path)

	if scene == null:
		push_error(
			"No se pudo cargar la escena: "
			+ scene_path
		)
		return

	var instance: Node = scene.instantiate()

	scene_container.add_child(instance)

	if instance.has_signal("jugar"):
		instance.jugar.connect(ir_a_aldea)


func ir_a_aldea() -> void:
	cargar_escena(ALDEA_SCENE)
