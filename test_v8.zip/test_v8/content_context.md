PROJECT CONTEXT
================
Persistent functional and development context for the Godot 4.7 conversational RPG.

DOCUMENT PURPOSE
----------------
This file is the shared project memory for intermittent development.
It records what the game is, what has been decided, what the current code does,
what is pending, and how the team works.

The document is not a copy of the source code and does not replace code review.
When the project is resumed, this document must be compared with the current code.

SOURCE OF TRUTH
---------------
Three states must remain distinct:

SPECIFICATION
- What the team has decided the game should do.

IMPLEMENTATION
- What the current code actually does.

PENDING
- A known difference, bug, improvement, unresolved decision, or inconsistency.

Never silently treat implementation as specification.
Never silently treat a pending item as resolved.
The README/read.me is not authoritative because it is outdated.

PROJECT IDENTITY
----------------
Type: conversational RPG.
Engine: Godot 4.7.
Current map/scene: aldea.

VISION
------
The player explores a map and interacts with NPCs through conversations.
Dialogue is the central gameplay mechanism.
External text scripts determine conversation content and can change game state
through inventory and XP effects.
The system should allow dialogue content to evolve independently from core game code.

DESIGN PRINCIPLES
-----------------
- Player experience and gameplay decisions have priority over implementation convenience.
- Dialogue content should remain external to game logic.
- Systems should remain simple and understandable.
- Code should be readable, well structured, and easy to maintain.
- Avoid unnecessary complexity and abstractions.
- Preserve existing behavior unless a change is explicitly agreed.
- Failures in external/script data should be safe and predictable.
- New features should not silently alter established gameplay rules.

TEAM ROLES
----------
USER
- Defines gameplay ideas and player experience.
- Makes gameplay/design decisions.
- Discusses technical decisions when useful or necessary.
- Normally implements changes by copying and pasting the code supplied by the assistant.
- Does not need to maintain the internal architecture independently.

ASSISTANT
- Acts as technical lead and primary implementer.
- Generates code for agreed functionality.
- Refactors when necessary.
- Maintains technical coherence across systems.
- Keeps code simple, readable, structured, and maintainable.
- May proactively give technical advice.
- Must not silently change gameplay decisions.
- Must explain technical consequences when a decision materially affects gameplay,
  content creation, maintainability, or future flexibility.

WORKFLOW
--------
IDEA
-> GAMEPLAY SPECIFICATION
-> CHECK AGAINST CURRENT CODE
-> IDENTIFY DISCREPANCIES
-> TECHNICAL APPROACH
-> USER DECISION WHEN GAMEPLAY IS AFFECTED
-> CODE
-> TEST
-> UPDATE CONTEXT

When resuming after an interruption:
1. Read this document.
2. Inspect the current project/code.
3. Compare implementation with specification.
4. Identify new discrepancies.
5. Continue only from the confirmed state.

When a task is completed:
1. Confirm intended behavior.
2. Implement.
3. Test.
4. Update the relevant context sections.
5. Mark the corresponding pending item resolved if applicable.

TEAM DECISION AUTHORITY
-----------------------
Gameplay and player-experience decisions belong to the user.
Technical implementation decisions normally belong to the assistant.
If a technical choice materially changes player experience, content workflow,
or future design possibilities, discuss it before treating it as final.

CURRENT STATUS
--------------
Development status: active/intermittent.
Current map: aldea.

Current major systems:
- player;
- NPCs;
- dialogue;
- XP/levels;
- inventory;
- local dialogue storage;
- GitHub synchronization;
- parser;
- validator;
- dialogue manager/UI.

PLAYER
------
SPECIFICATION:
- The player moves around the current map, aldea.
- Player has XP and a level.
- Level progression:
  A1 -> A2 -> B1 -> B2 -> C1.
- XP determines the current level.
- XP is constrained to 0-740.
- Level is used to select the level-specific dialogue script.
- Progress is calculated within the current level's XP range.
- Level and progress are displayed on screen.
- If no saved game exists, the initial inventory is empty.

IMPLEMENTATION:
- XP and level are implemented in player.gd.
- Current XP limits/ranges:
  A1: 0-70
  A2: 71-120
  B1: 121-340
  B2: 341-410
  C1: 411-740.
- XP changes are clamped to 0-740.
- Level is recalculated after XP changes.
- XP changes emit xp_changed.
- Dialogue UI displays the current level and progress.
- Saved XP and inventory are loaded from user://save/status.txt.
- If the save file does not exist, the player remains with initial values.
- Initial inventory is therefore empty.

PLAYER MOVEMENT
---------------
IMPLEMENTATION:
- Directional movement using ui_left, ui_right, ui_up and ui_down.
- Click/touch movement toward the selected position.
- Directional input takes priority over click/touch destination movement.

PENDING:
- Final desired movement behavior remains to be reviewed.

INVENTORY
---------
SPECIFICATION:
- Inventory items are strings.
- Items are added and removed by dialogue script effects.
- Inventory persists during the game session.
- Inventory is checked by dialogue conditions.
- Inventory determines NPC follow behavior.
- If an NPC's name is in the inventory, that NPC can follow the player.
- If the NPC's name is not in the inventory, the NPC returns according to
  its configured follow behavior.
- Initial inventory is empty when no saved game exists.

IMPLEMENTATION:
- Inventory is stored in DialogueManager as Array[String].
- Items are normalized to lowercase when added, removed, loaded and checked.
- Inventory is saved in user://save/status.txt.
- Inventory is loaded from user://save/status.txt.
- No separate initial-inventory file is used.

NPCS
----
SPECIFICATION:
NPCs have:
- name;
- sprite;
- position;
- interaction behavior.

FOLLOW BEHAVIOR:
- NPC follows the player when the player's inventory contains the NPC name.
- NPC maintains a distance rather than staying directly on top of the player.
- When the required inventory entry is removed, follow behavior stops.
- Depending on the NPC follow type, the NPC can remain where it stopped or
  return to the stored follow position.

CURRENT ALDEA NPCS
------------------
- juan
- charo
- luis
- peter

Dialogue files do not have to exist for every NPC because fallback rules apply.

NPC RETURN / FOLLOW POSITION
----------------------------
IMPLEMENTATION:
- The NPC currently stores its follow position when following starts.
- When following stops, an NPC configured to return can move back to that position.

SPECIFICATION:
- This behavior is currently accepted as the working follow-position behavior.

NOTE:
- The original "save NPC position when dialogue starts" proposal is no longer
  an active pending item.

DIALOGUE TRIGGER AND INTERRUPTION
---------------------------------
IMPLEMENTATION:
- Contact/interaction with an NPC can start dialogue.
- If the player leaves the NPC interaction area while dialogue is active,
  the dialogue closes.
- Player movement is not generally disabled just because dialogue is active.

DIALOGUE SCRIPT SELECTION
-------------------------
SPECIFICATION:
When the player interacts with an NPC, search in this order:

1. <map>_<npc>_<player_level>.txt
2. <map>_<npc>.txt
3. generico.txt
4. If none exists: no dialogue.

The level used is the player's current level when the dialogue is selected.

IMPORTANT:
File fallback and validation fallback are different.
If a selected file exists but is invalid, do not continue to the next filename.
Use fallo.txt instead.

IMPLEMENTATION:
- NPC get_dialogue_file() performs the selection.
- Runtime files are searched in user://dialogues/.
- The level-specific file is checked first.
- NPC-specific file is checked second.
- generico.txt is checked last.
- If no file exists, no dialogue starts.
- NPC names are converted to lowercase when building the dialogue filename.

DIALOGUE STORAGE
----------------
SPECIFICATION:
- Runtime dialogue files are read from user://dialogues/.
- GitHub is a synchronization source.
- res://dialogues/ is not used as the runtime dialogue source.
- The first execution creates user://dialogues/ if necessary.

IMPLEMENTATION:
- DialogueManager uses:
  user://dialogues/
- DialogueUpdater creates the local directory if necessary.
- No runtime fallback to res://dialogues/ is intended.

GITHUB SYNCHRONIZATION
----------------------
SPECIFICATION:
- GitHub is the source of the dialogue scripts.
- The intended synchronized local state is an exact copy of the relevant
  GitHub dialogue folder.
- Synchronization is independent from scene loading.
- The game scenes load normally while synchronization occurs.
- The human player is not expected to interact before synchronization has
  practically completed because the synchronization is much faster than
  normal human interaction.
- No res://dialogues/ copy is used as an initial source.

IMPLEMENTATION:
- DialogueUpdater is an autoload.
- It creates user://dialogues/ if necessary.
- The GitHub synchronization call is currently controlled from initialize_dialogues().
- The current development configuration has the GitHub call commented/disabled.
- When enabled, the updater retrieves .txt files from the configured GitHub folder
  and downloads them into user://dialogues/.
- Files no longer present in the GitHub listing are removed locally.
- Runtime dialogue reading remains local.

PENDING:
- Review the final enabled synchronization implementation and confirm the exact-copy
  behavior and error handling.
- Confirm the final decision for enabling synchronization in the normal game flow.

DIALOGUE VALIDATION AND PROCESSING
----------------------------------
SPECIFICATION:
Flow:
script selection
-> validation
-> if invalid, fallo.txt
-> parsing
-> dialogue data/dictionary
-> dialogue manager
-> dialogue UI.

IMPLEMENTATION:
- DialogueParser parses external text scripts.
- DialogueValidator validates parser output and parser errors.
- Invalid selected scripts use fallo.txt.
- fallo.txt is itself parsed and validated.
- If fallo.txt is unavailable or invalid, dialogue cannot proceed.

STATUS:
- Parser and validator behavior is considered closed.

DIALOGUE LANGUAGE
-----------------
Scripts may contain:
- dialogue text;
- player options;
- inventory conditions;
- jumps;
- RANDOM jumps;
- effects.

Text:
- Consecutive text lines can form the text of a dialogue node.
- Comments beginning with -- are ignored at runtime.

CONDITIONS
----------
IMPLEMENTATION:
- Conditions are evaluated in the order in which they appear.
- The first satisfied condition causes an immediate jump to its destination.
- Multiple required inventory items mean all listed items must be present.
- Conditions can create chains of automatic jumps.

Example conceptual flow:
node A -> condition -> node B -> condition -> node C.

OPTIONS AND EFFECTS
-------------------
A player response can produce effects before the next dialogue destination.

Current effect types:
- add item;
- remove item;
- add/subtract XP.

Items are strings.

Dialogue can therefore change persistent session state:
conversation -> inventory/XP change -> later dialogue behavior can change.

There is no automatic XP reward merely for reaching the end of a dialogue.
XP changes through explicit script effects.

RANDOM
------
SPECIFICATION:
- RANDOM is an automatic jump.
- It selects another node from the same script.
- The current node is excluded.
- It can select any other node regardless of whether that node has text,
  options, conditions or another jump.
- RANDOM is allowed to create chains and cycles.

IMPLEMENTATION:
- DialogueManager implements this behavior with _get_random_node().
- The current node is excluded.
- No additional node-type restriction is applied.

STATUS:
- Closed.

DIALOGUE END STATES
-------------------
- There is no special final-node type.
- A node without options or continuation can act as an endpoint.
- A dialogue may also be interrupted by leaving the NPC interaction area.

VALIDATION
----------
SPECIFICATION:
- Validation should prevent invalid script data from being executed.
- Duplicate option numbers are allowed.
- Option numbers are not used to identify the selected option at runtime.

IMPLEMENTATION:
- Parser reads option numbers.
- Validator validates option destinations.
- Validator no longer checks duplicate option numbers.
- Duplicate option numbers therefore do not invalidate a script.
- Malformed XP/action syntax is handled by parser validation rules currently
  implemented in DialogueParser.

STATUS:
- Parser/validator system considered closed for the currently agreed behavior.

NPC NAME NORMALIZATION
----------------------
SPECIFICATION:
- NPC names and dialogue filenames should be handled consistently.
- Case differences such as "charo" and "ChaRO" should not prevent dialogue lookup.

IMPLEMENTATION:
- Inventory item names are normalized to lowercase.
- NPC dialogue filename construction currently uses the NPC name provided
  by the scene and converts it to lowercase.
- Current testing has confirmed that lookup of names with different casing,
  such as charo / ChaRO, does not currently produce a problem.

STATUS:
- Considered resolved for current behavior.

COMMENTS IN SCRIPT FILES
------------------------
SPECIFICATION:
- Comments are author information only.
- Comments have no gameplay function.
- Comments are ignored at runtime.

IMPLEMENTATION:
- DialogueParser removes text after -- from each line before processing it.

STATUS:
- No parser change required.
- Outdated comments can be corrected as content maintenance when scripts are reviewed.

CURRENT CONTENT
---------------
Current project contains dialogue examples for:
- Juan
- Charo
- Peter.

Luis currently has no dedicated dialogue file, so fallback rules may lead to
generico.txt.

Some dialogue comments may not match the actual script contents.
This does not affect runtime.

SAVE SYSTEM
-----------
IMPLEMENTATION:
- Save file:
  user://save/status.txt
- Saved values currently include:
  xp
  inventory
- DialogueManager loads saved status after startup using call_deferred().
- DialogueManager saves status when dialogue ends.

INITIAL GAME STATE
------------------
SPECIFICATION:
- If no save file exists:
  XP = 0
  inventory = empty.
- No external initial inventory file is required.

ARCHITECTURAL MAP
-----------------
PLAYER
  |
  +-- movement
  +-- XP / level
  +-- inventory state through DialogueManager
  |
  v
NPC INTERACTION
  |
  v
DIALOGUE FILE SELECTION
  |
  v
VALIDATION
  |
  v
PARSER
  |
  v
DIALOGUE DATA
  |
  v
DIALOGUE MANAGER
  |
  v
DIALOGUE UI

GITHUB
  |
  v
user://dialogues/
  |
  v
DIALOGUE FILE SELECTION

IMPORTANT SYSTEM CONTRACTS
--------------------------
PLAYER -> DIALOGUE
- Player level determines the level-specific dialogue filename.

NPC -> DIALOGUE
- NPC name and current map determine dialogue filename selection.

DIALOGUE -> INVENTORY
- Conditions read inventory.
- Effects add/remove items.

DIALOGUE -> XP
- Effects can modify XP.

INVENTORY -> NPC
- NPC name in inventory determines follow behavior.

GITHUB -> LOCAL DIALOGUES
- GitHub supplies dialogue data for synchronization.
- Runtime dialogue reading uses the local synchronized copy.
- res://dialogues/ is not part of the runtime dialogue storage.

PENDING ITEMS
-------------
PENDING 1 - PLAYER MOVEMENT
- Review current directional/click-touch movement.
- Decide final desired behavior.

PENDING 2 - GITHUB SYNCHRONIZATION
- Review the final enabled synchronization implementation.
- Guarantee the local dialogue folder becomes an exact copy of GitHub.
- Review failure and update behavior.

PENDING 3 - DIALOGUE USE DURING SYNCHRONIZATION
- Although synchronization is independent and faster than normal human
  interaction, review whether an explicit synchronization-state protection
  is needed later.

PENDING 4 - ATOMIC GITHUB SYNCHRONIZATION
- Review whether synchronization should use a temporary location and final
  replacement, if this becomes necessary for stronger consistency.

PENDING 5 - OUTDATED SCRIPT COMMENTS
- Review comments that no longer match script contents.
- This is content maintenance only and does not require parser changes.

BACKLOG CATEGORIES
------------------
BUGS
- Problems where current behavior is incorrect.

IMPROVEMENTS
- Existing behavior that should be improved.

NEW FEATURES
- Functionality that does not yet exist.

DESIGN DECISIONS
- Questions about intended player experience that require a team decision.

DONE CRITERIA
-------------
A task is considered complete when:
- intended behavior is clearly defined;
- implementation matches the specification;
- existing systems are not unintentionally broken;
- relevant failure cases are controlled;
- the behavior has been tested;
- context has been updated;
- related pending item is marked resolved.

DECISIONS TAKEN
---------------
- XP determines player level.
- Level selects level-specific dialogue scripts.
- Inventory items are strings.
- Inventory affects dialogue conditions and NPC following.
- Dialogue scripts can modify inventory and XP.
- GitHub is the source for synchronization; runtime reads local dialogue files.
- res://dialogues/ is not used for runtime dialogue storage.
- user://dialogues/ is created when necessary.
- Synchronization is independent from scene loading.
- Initial inventory is empty when no saved game exists.
- RANDOM can select any node except the current node.
- RANDOM may create chains and cycles.
- Duplicate option numbers are allowed.
- Option numbers are not used to identify the selected option.
- Script comments are author information and are ignored at runtime.
- NPC name lookup is handled case-insensitively for the current implementation.
- README/read.me is not authoritative.

DECISIONS DISCARDED
-------------------
- Using res://dialogues/ as the runtime dialogue source.
- Copying res://dialogues/ as the initial dialogue source.
- Requiring unique option numbers.
- Restricting RANDOM to specific node types.
- Loading a separate initial inventory file.
- Saving the NPC return position specifically when dialogue starts.

KNOWN PROBLEMS
--------------
- GitHub synchronization still needs final review before being considered closed.
- Player movement still needs final gameplay review.
- Some script comments may be outdated.
- Synchronization atomicity and synchronization-state handling remain technical
  review items, although the current design assumes synchronization completes
  before normal human interaction.

TEST STATUS
-----------
Dialogue:
- specific level dialogue: known/implemented
- NPC-specific fallback: known/implemented
- generic fallback: known/implemented
- no-file behavior: known/implemented
- invalid script -> fallo.txt: known/implemented
- inventory conditions: known/implemented
- item effects: known/implemented
- XP effects: known/implemented
- RANDOM: tested/confirmed
- dialogue interruption by leaving NPC area: known/implemented
- duplicate option numbers: tested/confirmed valid

Player:
- XP/level calculation: known/implemented
- displayed level/progress: known/implemented
- initial inventory when no save exists: confirmed
- movement: pending review

NPC:
- follow by inventory name: known/implemented
- distance-based following: known/implemented
- NPC name case handling: tested/confirmed
- follow-position behavior: implemented

GitHub:
- local dialogue usage: known/implemented
- user://dialogues/ creation: implemented
- res://dialogues/ not used: confirmed
- synchronization workflow: pending final review
- synchronization during scene loading: independent by design

CONTEXT MAINTENANCE
-------------------
The context document itself is generated and maintained as part of the project workflow.

Generation/update procedure:
1. Start from the latest version of content_context.md.
2. Inspect the current project code and relevant dialogue files.
3. Compare the code with the existing specification.
4. Preserve confirmed decisions.
5. Add newly confirmed behavior to the appropriate section.
6. Add discrepancies to PENDING.
7. When a pending item is resolved, update SPECIFICATION and IMPLEMENTATION
   and mark/remove the pending item.
8. Do not use outdated documentation as authority over verified code.
9. Keep the document concise: record decisions, contracts, behavior, pending work,
   and important technical constraints, not every implementation detail.
10. Save the resulting document as plain UTF-8 text named:
    content_context.md

CONTEXT UPDATE RULE
-------------------
At the end of a significant development session, update this file if any of the
following changed:
- gameplay specification;
- system behavior;
- architecture;
- pending items;
- important bugs;
- decisions;
- test status.

The goal is that a new session can recover the project state by reading this
document and then verifying it against the current code.

DEVELOPMENT PRIORITY
--------------------
Current recommended priority:
1. GitHub synchronization final review
2. Player movement
3. Dialogue use during synchronization
4. Atomic synchronization
5. Outdated script comments

END OF CONTEXT
==============
