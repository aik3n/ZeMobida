
#archivo: game.gd
extends Node


const BIENVENIDA_SCENE := "res://escenas/bienvenida.tscn"
const ALDEA_SCENE := "res://escenas/aldea.tscn"


@onready var scene_container: Node = $SceneContainer

@onready var ui: CanvasLayer = $UI

@onready var estado_panel: Panel = $UI/Estado/Panel
@onready var boton_estado: Button = $UI/BotonEstado
@onready var boton_cerrar: Button = $UI/Estado/Panel/Cerrar

@onready var estado_titulo: Label = $UI/Estado/Panel/Titulo
@onready var estado_nivel: Label = $UI/Estado/Panel/Nivel
@onready var estado_progreso: Label = $UI/Estado/Panel/Progreso
@onready var estado_barra_xp: ProgressBar = $UI/Estado/Panel/BarraXP
@onready var estado_inventario: Label = $UI/Estado/Panel/Inventario


var mapa_actual: Node = null


const NIVELES := {
	"a1": 70,
	"a2": 120,
	"b1": 340,
	"b2": 410,
	"c1": 740
}


const ORDEN_NIVELES := [
	"a1",
	"a2",
	"b1",
	"b2",
	"c1"
]


func _ready() -> void:

	estado_panel.visible = false

	boton_estado.pressed.connect(
		_abrir_estado
	)

	boton_cerrar.pressed.connect(
		_cerrar_estado
	)

	cargar_escena(
		BIENVENIDA_SCENE
	)



func cargar_escena(
	scene_path: String
) -> void:

	for child in scene_container.get_children():
		child.queue_free()

	mapa_actual = null

	ui.visible = scene_path != BIENVENIDA_SCENE

	var scene: PackedScene = load(
		scene_path
	)

	if scene == null:

		push_error(
			"No se pudo cargar la escena: "
			+ scene_path
		)

		return

	var instance: Node = scene.instantiate()

	if scene_path != BIENVENIDA_SCENE:
		mapa_actual = instance

	scene_container.add_child(
		instance
	)

	if scene_path != BIENVENIDA_SCENE:
		DialogueManager.load_player_status()

	if instance.has_signal("jugar"):

		instance.jugar.connect(
			ir_a_aldea
		)



func ir_a_aldea() -> void:

	cargar_escena(
		ALDEA_SCENE
	)



func _abrir_estado() -> void:

	_actualizar_estado()

	estado_panel.visible = true



func _cerrar_estado() -> void:

	estado_panel.visible = false



func _actualizar_estado() -> void:

	if mapa_actual == null:

		return

	var player = mapa_actual.get_node_or_null(
		"player"
	)

	if player == null:

		push_warning(
			"No se encontró el Player para mostrar el estado."
		)

		return

	_actualizar_nivel(
		player
	)

	_actualizar_experiencia(
		player
	)

	_actualizar_inventario()



func _actualizar_nivel(
	player: Node
) -> void:

	var nivel: String = str(
		player.nivel
	).to_lower()

	estado_nivel.text = nivel.to_upper()



func _actualizar_experiencia(
	player: Node
) -> void:

	var nivel: String = str(
		player.nivel
	).to_lower()

	var xp: int = int(
		player.xp
	)

	if not NIVELES.has(nivel):

		estado_progreso.text = "XP: %d" % xp

		estado_barra_xp.min_value = 0
		estado_barra_xp.max_value = 1
		estado_barra_xp.value = 0

		return

	var indice := ORDEN_NIVELES.find(
		nivel
	)

	if indice == -1:

		return

	var limite_superior: int = NIVELES[nivel]

	var limite_inferior := 0

	if indice > 0:

		var nivel_anterior: String = (
			ORDEN_NIVELES[indice - 1]
		)

		limite_inferior = (
			NIVELES[nivel_anterior] + 1
		)

	var rango := (
		limite_superior
		- limite_inferior
	)

	if rango <= 0:

		estado_progreso.text = (
			"XP: %d / %d"
			% [xp, limite_superior]
		)

		estado_barra_xp.min_value = 0
		estado_barra_xp.max_value = 1
		estado_barra_xp.value = 1

		return

	var progreso := (
		xp - limite_inferior
	)

	progreso = clamp(
		progreso,
		0,
		rango
	)

	estado_progreso.text = (
		"XP: %d / %d"
		% [xp, limite_superior]
	)

	estado_barra_xp.min_value = 0
	estado_barra_xp.max_value = rango
	estado_barra_xp.value = progreso



func _actualizar_inventario() -> void:

	var inventario: Array[String] = (
		DialogueManager.inventory
	)

	if inventario.is_empty():

		estado_inventario.text = (
			"Inventario vacío"
		)

		return

	var texto := ""

	for item in inventario:

		if not texto.is_empty():
			texto += "\n"

		texto += "- " + item

	estado_inventario.text = texto
