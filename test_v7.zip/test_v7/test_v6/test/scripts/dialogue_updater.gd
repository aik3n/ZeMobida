extends Node


const LOCAL_FOLDER: String = "user://dialogues/"
const DEFAULT_FOLDER: String = "res://dialogues/"


# CONFIGURACIÓN GITHUB
const GITHUB_USER: String = "aik3n"
const GITHUB_REPO: String = "ZeMobida"
const GITHUB_BRANCH: String = "main"
const GITHUB_FOLDER: String = "guiones"


var pending_downloads: int = 0
var github_files: Array[Dictionary] = []
var github_file_names: Array[String] = []



func _ready() -> void:

	initialize_dialogues()



func initialize_dialogues() -> void:
	_create_local_folder()

	if _local_is_empty():
		_copy_default_dialogues()

	#_download_from_github()



func _create_local_folder() -> void:

	var dir: DirAccess = DirAccess.open(
		"user://"
	)


	if dir == null:

		push_error(
			"No se puede acceder a user://"
		)

		return


	if not dir.dir_exists("dialogues"):

		dir.make_dir(
			"dialogues"
		)



func _local_is_empty() -> bool:

	var dir: DirAccess = DirAccess.open(
		LOCAL_FOLDER
	)


	if dir == null:

		return true


	return dir.get_files().is_empty()



func _copy_default_dialogues() -> void:

	var source: DirAccess = DirAccess.open(
		DEFAULT_FOLDER
	)


	if source == null:

		push_warning(
			"No existe res://dialogues/"
		)

		return


	for file_name: String in source.get_files():

		if not file_name.ends_with(".txt"):

			continue


		DirAccess.copy_absolute(
			DEFAULT_FOLDER + file_name,
			LOCAL_FOLDER + file_name
		)



func _download_from_github() -> void:

	var url: String = (
		"https://api.github.com/repos/"
		+ GITHUB_USER
		+ "/"
		+ GITHUB_REPO
		+ "/contents/"
		+ GITHUB_FOLDER
		+ "?ref="
		+ GITHUB_BRANCH
	)


	var http: HTTPRequest = HTTPRequest.new()

	add_child(http)


	http.request_completed.connect(
		_on_github_list_received.bind(http)
	)


	var error: Error = http.request(url)


	if error != OK:

		print(
			"No se pudo conectar con GitHub"
		)

		http.queue_free()



func _on_github_list_received(
	result: int,
	response_code: int,
	headers: PackedStringArray,
	body: PackedByteArray,
	http: HTTPRequest
) -> void:


	http.queue_free()


	if response_code != 200:

		print(
			"GitHub no disponible, usando locales"
		)

		return


	var data: Variant = JSON.parse_string(
		body.get_string_from_utf8()
	)


	if data == null:

		push_warning(
			"Respuesta incorrecta de GitHub"
		)

		return


	for file: Dictionary in data:

		if file["name"].ends_with(".txt"):

			github_files.append(
				file
			)

			github_file_names.append(
				file["name"]
			)


	pending_downloads = github_files.size()


	if pending_downloads == 0:

		_clean_local_folder()

		return


	for file: Dictionary in github_files:

		_download_file(
			file
		)



func _download_file(
	file: Dictionary
) -> void:


	var http: HTTPRequest = HTTPRequest.new()

	add_child(http)


	http.request_completed.connect(
		_on_file_downloaded.bind(
			http,
			file["name"]
		)
	)


	http.request(
		file["download_url"]
	)



func _on_file_downloaded(
	result: int,
	response_code: int,
	headers: PackedStringArray,
	body: PackedByteArray,
	http: HTTPRequest,
	file_name: String
) -> void:


	http.queue_free()


	if response_code == 200:

		var path: String = (
			LOCAL_FOLDER
			+ file_name
		)


		var save: FileAccess = FileAccess.open(
			path,
			FileAccess.WRITE
		)


		if save != null:

			save.store_buffer(
				body
			)


			print(
				"Actualizado: ",
				file_name
			)


	else:

		print(
			"Error descargando: ",
			file_name
		)


	pending_downloads -= 1


	if pending_downloads == 0:

		_clean_local_folder()

		print(
			"Sincronización completa"
		)



func _clean_local_folder() -> void:

	var dir: DirAccess = DirAccess.open(
		LOCAL_FOLDER
	)


	if dir == null:

		return


	for file_name: String in dir.get_files():

		if not file_name.ends_with(".txt"):

			continue


		if not github_file_names.has(file_name):

			var path: String = (
				LOCAL_FOLDER
				+ file_name
			)


			var error: Error = DirAccess.remove_absolute(
				path
			)


			if error == OK:

				print(
					"Eliminado: ",
					file_name
				)

			else:

				push_warning(
					"No se pudo eliminar: "
					+ file_name
				)
