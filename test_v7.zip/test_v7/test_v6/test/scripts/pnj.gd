extends CharacterBody2D

@export var nombre: String = "PNJ"
@export var sprite: Texture2D

var player_nearby := false

var player: CharacterBody2D = null
var posicion_inicial: Vector2

var siguiendo := false
var a_distancia_segura := false

const VELOCIDAD_SEGUIR := 100.0
const DISTANCIA_PARAR := 80.0
const DISTANCIA_REANUDAR := 120.0


@onready var sprite_2d: Sprite2D = $Sprite2D


func _ready():

	sprite_2d.texture = sprite

	posicion_inicial = global_position

	player = get_tree().current_scene.get_node_or_null(
		"player"
	)



func _physics_process(_delta):

	if player == null:
		return


	_actualizar_seguimiento()


	if siguiendo:

		_seguir_player()

	else:

		volver_posicion_inicial()



func _actualizar_seguimiento():

	siguiendo = DialogueManager.has_item(
		nombre.to_lower()
	)


	if not siguiendo:

		a_distancia_segura = false



func _seguir_player():

	var distancia := global_position.distance_to(
		player.global_position
	)


	# Está suficientemente cerca.
	# No se mueve hasta que el jugador se aleja.
	if a_distancia_segura:

		if distancia > DISTANCIA_REANUDAR:

			a_distancia_segura = false

		else:

			velocity = Vector2.ZERO
			move_and_slide()
			return



	# Ha llegado a la distancia cómoda.
	if distancia <= DISTANCIA_PARAR:

		a_distancia_segura = true

		velocity = Vector2.ZERO
		move_and_slide()

		return



	var direccion := global_position.direction_to(
		player.global_position
	)


	velocity = direccion * VELOCIDAD_SEGUIR

	move_and_slide()



func volver_posicion_inicial():

	var distancia := global_position.distance_to(
		posicion_inicial
	)


	if distancia < 5:

		velocity = Vector2.ZERO
		return



	var direccion := global_position.direction_to(
		posicion_inicial
	)


	velocity = direccion * VELOCIDAD_SEGUIR

	move_and_slide()



func get_map_name() -> String:

	var scene_path := get_tree().current_scene.scene_file_path

	return scene_path.get_file().get_basename()



func get_dialogue_file() -> String:

	var map_name := get_map_name()

	var player_node = get_tree().current_scene.get_node_or_null(
		"player"
	)


	if player_node == null:

		push_error(
			"No se encontró el Player."
		)

		return ""



	var base_name := "%s_%s" % [
		map_name,
		nombre
	]



	# Primero busca diálogos actualizados
	var level_file := "%s_%s.txt" % [
		base_name,
		player_node.nivel
	]


	if FileAccess.file_exists(
		"user://dialogues/" + level_file
	):

		return level_file



	var generic_file := "%s.txt" % base_name


	if FileAccess.file_exists(
		"user://dialogues/" + generic_file
	):

		return generic_file



	if FileAccess.file_exists(
		"user://dialogues/generico.txt"
	):

		return "generico.txt"



	push_error(
		"No existe diálogo para: "
		+ base_name
	)


	return ""



func _on_interaction_area_body_entered(body):

	if body.name != "player":

		return


	player_nearby = true



	if not DialogueManager.dialogue_active:

		var dialogue_file := get_dialogue_file()


		if dialogue_file.is_empty():

			return



		DialogueManager.start_dialogue(
			"user://dialogues/" + dialogue_file,
			nombre
		)



func _on_interaction_area_body_exited(body):

	if body.name != "player":

		return


	player_nearby = false



	if DialogueManager.dialogue_active:

		DialogueManager.end_dialogue()



func _on_interaction_area_area_exited(area):

	pass
